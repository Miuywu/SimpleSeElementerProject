chrome.devtools.panels.create(
  "ElementerMod",
  "assets/favicon-32x32.png",
  "panel.html",
  function(panel) {
    // code invoked on panel creation
  }
)
