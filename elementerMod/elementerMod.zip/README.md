# Elementer

A chrome devtools extension which helps in inspecting elements in the web page and generate page element JSON to support the [SimpleSe](https://github.com/RationaleEmotions/SimpleSe) selenium based Java framework.
